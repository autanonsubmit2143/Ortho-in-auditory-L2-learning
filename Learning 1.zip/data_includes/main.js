PennController.ResetPrefix()

DebugOff()

Sequence("hc_calib", "screening_test", "hc_results", "consent", "general-instructions", "general-instructions2",
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
"send", "final_message");


//headphone Check

newTrial("hc_calib",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .center()
            .print()
        ,
        newText("Test de perception")
            .bold()
        ,
        newText("<p></strong>Vous devez porter des écouteurs pour continuer</strong></p><p>Tout d'abord, réglez le volume de votre ordinateur à environ 25% <p> <p>Appuyez sur le bouton ci-dessous, puis augmentez le volume de votre ordinateur jusqu'à ce que le son soit suffisamment fort tout en étant confortable.<p><p>Vous pouvez écouter le sonet modifier votre volume autant de fois que vous le souhaitez.<p><p>Appuyez sur Continuer lorsque vous avez terminé<p>")
	        .center()
	        .css("background", "white")
        ,
        newAudio("noise_calib","noise_calib_stim.wav")
            .cssContainer({"margin-bottom":"1em"})
	        .css( "border" , "solid 3px red" )
	        .center()
            .print()
            .play()
        ,
        newButton("ac_test_button", "Continuer")
            .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait(getAudio("noise_calib").test.hasPlayed())
);

newTrial("screening_test",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        newVar("counter_hc",0)
            .global()
        ,
        newText("Test de perception")
            .bold()
            .center()
        ,
        newText("<p></strong>Lorsque vous appuierez sur le bouton  <b>Lecture ci-dessous</b>, vous entendrez trois sons séparés par des silences.</strong></p><p>Vous devez décider LEQUEL DE CES TROIS SONS A LA PLUS FAIBLE INTENSITE (est le moins fort) - 1, 2 ou 3?<p> <p>Les sons ne peuvent être joués qu'une seule fois!<p>")
	        .center()
	        .css("background", "white")
	    ,
	    newButton("hc1_play", "Lecture ci-dessous")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc1", "Le PREMIER son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("correct_hc1", "Le DEUXIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("incorrect2_hc1", "Le TROISIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    getButton("hc1_play")
	        .wait()
	    ,
	    newAudio("hc1","antiphase_HC_ISO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc1")
	        .add(getText("incorrect1_hc1"), getText("correct_hc1"), getText("incorrect2_hc1"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc1")
	        .test.selected(getText("correct_hc1"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	   ,
	   newButton("hc2_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc2", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc2", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc2", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc2_play")
	        .wait()
	    ,
	    newAudio("hc2","antiphase_HC_IOS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc2")
	        .add(getText("incorrect1_hc2"), getText("incorrect2_hc2"), getText("correct_hc2"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc2")
	        .test.selected(getText("correct_hc2"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc3_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc3", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect1_hc3", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc3", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc3_play")
	        .wait()
	    ,
	    newAudio("hc3","antiphase_HC_SOI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc3")
	        .add(getText("correct_hc3"), getText("incorrect1_hc3"), getText("incorrect2_hc3"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc3")
	        .test.selected(getText("correct_hc3"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc4_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc4", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect1_hc4", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc4", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc4_play")
	        .wait()
	    ,
	    newAudio("hc4","antiphase_HC_SIO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc4")
	        .add(getText("correct_hc4"), getText("incorrect1_hc4"), getText("incorrect2_hc4"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc4")
	        .test.selected(getText("correct_hc4"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc5_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc5", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc5", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc5", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc5_play")
	        .wait()
	    ,
	    newAudio("hc5","antiphase_HC_OSI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc5")
	        .add(getText("incorrect1_hc5"), getText("correct_hc5"), getText("incorrect2_hc5"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc5")
	        .test.selected(getText("correct_hc5"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc6_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc6", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc6", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc6", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc6_play")
	        .wait()
	    ,
	    newAudio("hc6","antiphase_HC_OIS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc6")
	        .add(getText("incorrect1_hc6"), getText("incorrect2_hc6"), getText("correct_hc6"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc6")
	        .test.selected(getText("correct_hc6"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("send", "Envoyer")
	        .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait()
);

newTrial("hc_results",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .success(
            newText("<p>Très bien!</p><p>Appuyez sur le bouton ci-dessous pour continuer.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("Continuer")
                .center()
                .size(100, 30)
                .css("border", "solid 5px white")
                .print()
                .wait()
                
        )
        .failure(
            newText("<p>Veuillez mettre des écouteurs et réessayer l'expérience plus tard.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newTimer(2500)
                .start()
                .wait()
        )
        .log()
);

//Instructions

newTrial("general-instructions",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("<p> <strong> Bonjour, Merci de votre participation à l’expérience : « Apprentissage de nouveaux mots » menée par l’Université de Potsdam.</strong> </p> <p>Cette expérience comprend trois sessions expérimentales, réparties sur trois jours. Lors des deux premiers jours, vous allez uniquement apprendre de nouveaux mots anglais. Lors du troisième jour, nous testerons également vos connaissances de ces mots.<p> Veuillez vous assurer que vous êtes dans une pièce calme. Vous devez utiliser des écouteurs. <p> Dans un premier temps, vous allez voir des images apparaître à l’écran une par une et vous entendrez le nom de chaque image. Veuillez essayer de vous souvenir le mieux possible des noms des images. Plus tard, il vous sera demandé de dénommer ces images. La première partie de l’expérience devrait prendre environ 20 minutes. Votre identité sera gardé anonyme et vos données seront traitées et stockées conformément à la loi européene sur la protection des données (DSGVO). Votre participation à l'étude nous aidera à mieux comprendre comment les gens apprennent et parlent une nouvelle langue. <p> <strong> Browser requirements: </strong> </p> Afin de participer à l'étude, veuillez vous assurer que vous utilisez le navigateur Google Chrome ou Firefox. Saisissez ensuite votre identifiant et cliquez sur le bouton Continuer ci-dessous. </p> <p> Si vous utilisez un autre navigateur, veuillez fermer la fenêtre de l'expérience et vous retirer de l'étude. <p> </p>")
    ,
    newText("Veuillez saisir votre Prolific ID et cliquer sur le bouton ci-dessous pour continuer.")
    ,
    newTextInput("input_ID")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour continuer")
        .center()
        .print()
        .wait()
    ,
    newVar("ID")
        .global()
        .set(getTextInput("input_ID"))
        .log()
);

newTrial("general-instructions2",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("Phase d’apprentissage - 1")
        .bold()
    ,
    newText("<p>Durant cette session, vous allez être familiarisés avec 20 nouveaux mots anglais, votre tâche consiste à les mémoriser et à vous rappeler l’image à laquelle ils correspondent. <p>Vous verrez apparaître à l’écran des images de plantes, d’animaux et d’objets. Les images apparaitront l’une après l’autre, accompagnées du mot qu’elles représentent. Votre tâche est d’apprendre le plus de mots possibles.")
    ,
    newText("Vous n'êtes PAS AUTORISÉ à prendre des notes.")
    ,
    newText("Assurez-vous que le son de votre appareil est activé.")
        .bold()
    ,
    newButton("wait", "Cliquez pour commencer")
        .center()
        .print()
        .wait()
);



// Ask for consent on recording

newTrial("consent",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
    ,
    newText("<p><strong>Déclaration de consentement</strong></p><p>J'accepte de participer à l'étude empirique Word Learning à l'Université de Potsdam. </p> <p> J’ai été informé du fait, et je l’accepte, que mes réponses vocales (fichiers audio) seront enregistrées et sauvegardées. </p> <p> J’ai été informée de la procédure de l’expèrience. </p> <p> En cliquant sur le bouton « accepter », j'accepte que mes données personnelles soient collectées dans le but de l'étude et à des fins d'administration et de mise en œuvre de l'étude ainsi qu'à des fins de recherche et évaluation statistique. Les données sont stockées de manière anonyme conformément à la loi allemande sur la protection des données (DSGVO). Les résultats de l'étude, mais pas les fichiers audio, sont rendus publics et peuvent être publiés dans la littérature spécialisée, bien que mon identité reste anonyme.</p> <p> L'étude est considérée comme terminée lorsqu'elle a été publiée, ou lorsque 10 ans se sont écoulés. Après la fin de l'étude, toutes les données personnelles (par exemple, date de naissance, adresse, nom) seront supprimées. Passé ce délai, les données non personnalisées ne pourront plus être supprimées, car il ne sera plus possible de me les attribuer. </p> <p> Je sais que je peux me retirer de l'enquête à tout moment. Cela n'aura aucune conséquence négative pour moi. Je sais également que j'ai consenti à rester anonyme. Le traitement ultérieur des données anonymisées peut être interrompu à tout moment, tant que les données personnelles n'ont pas encore été supprimées. </p>")
        .cssContainer("font-size", "25px")
        .print()
    ,
    newButton("consent", "ACCEPTER")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
        .wait()
        .log()
);

//Learning 

Template("LearningSession_TokenOne.csv", row =>
    newTrial("TokenOne",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
);

Template("LearningSession_TokenTwo.csv", row =>
    newTrial("TokenTwo",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
)

Template("LearningSession_TokenThree.csv", row =>
    newTrial("TokenThree",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
)

Template("LearningSession_TokenFour.csv", row =>
    newTrial("TokenFour",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
                newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
)


SendResults("send");

// Completion screen


Template(GetTable("final_message.csv"),
    fin =>
        newTrial("final_message",
            getVar("counter_hc")
                .test.is(v => v > 4)
                .failure(end())
            ,
            exitFullscreen()
            ,
            newText(fin.line1)
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("void")
                .wait()
        )
        .log("ID", getVar("ID"))
);


