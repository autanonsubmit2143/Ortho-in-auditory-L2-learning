PennController.ResetPrefix(null)

uniqueID = 10000+Math.round(99999*Math.random())

if (Math.random() >= 0.5)

Sequence("hc_calib", "screening_test", "hc_results",
    
    "init_rec",

    "general-instructions",
    
    "audio_check",
    
    "instructions-naming-task", 
    
    "trial-run-naming",
    
    "clear?",
    
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    "instructions-reading-task-FJ", 
    
    "trial-run-reading-FJ",
    
    "clear?2",
    
    randomize("reading-task1-FJ"),
    
    randomize("reading-task2-FJ"),
    
    randomize("reading-task3-FJ"),
    
    randomize("reading-task4-FJ"),
    
    "instructions-dictation-task", 
    
    "trial-run-dictation",
    
    "clear?3",
    
    randomize("dictation-task"),
    
    "instructions-french-words",
    
    sepWith("upload_async", randomize("french_words")),"upload_sync",
    
    "send",
    
    "completion-screen")
    
else

Sequence( "hc_calib", "screening_test", "hc_results",
    
    "init_rec",

    "general-instructions",
    
    "audio_check",
    
    "instructions-naming-task", 
    
    "trial-run-naming",
    
    "clear?",
   
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    sepWith("upload_async", randomize("naming-task")),"upload_sync",
    
    "instructions-reading-task-JF", 
    
    "trial-run-reading-JF",
    
    "clear?2",
    
    randomize("reading-task1-JF"),
    
    randomize("reading-task2-JF"),
    
    randomize("reading-task3-JF"),
    
    randomize("reading-task4-JF"),
    
    "instructions-dictation-task", 
    
    "trial-run-dictation",
    
    "clear?3",
    
    randomize("dictation-task"),
    
    "instructions-french-words",
    
    sepWith("upload_async", randomize("french_words")),"upload_sync",
    
    "send",
    
    "completion-screen");


InitiateRecorder("https://www.ling.uni-potsdam.de/cslmlab/arina_thesis/arina_thesis_upload.php").label("init_rec")

UploadRecordings("upload_async", "noblock")

UploadRecordings("upload_sync", "block")

SendResults("send") 


    

//headphone Check

newTrial("hc_calib",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .center()
            .print()
        ,
        newText("Test de perception")
            .bold()
        ,
        newText("<p></strong>Vous devez porter des écouteurs pour continuer</strong></p><p>Tout d'abord, réglez le volume de votre ordinateur à environ 25% <p> <p>Appuyez sur le bouton ci-dessous, puis augmentez le volume de votre ordinateur jusqu'à ce que le son soit suffisamment fort tout en étant confortable.<p><p>Vous pouvez écouter le sonet modifier votre volume autant de fois que vous le souhaitez.<p><p>Appuyez sur Continuer lorsque vous avez terminé<p>")
	        .center()
	        .css("background", "white")
        ,
        newAudio("noise_calib","noise_calib_stim.wav")
            .cssContainer({"margin-bottom":"1em"})
	        .css( "border" , "solid 3px red" )
	        .center()
            .print()
            .play()
        ,
        newButton("ac_test_button", "Continuer")
            .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait(getAudio("noise_calib").test.hasPlayed())
);


newTrial("screening_test",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        newVar("counter_hc",0)
            .global()
            .log("final")
        ,
        newText("Test de perception")
            .bold()
            .center()
        ,
        newText("<p></strong>Lorsque vous appuierez sur le bouton  <b>Lecture ci-dessous</b>, vous entendrez trois sons séparés par des silences.</strong></p><p>Vous devez décider LEQUEL DE CES TROIS SONS A LA PLUS FAIBLE INTENSITE (est le moins fort) - 1, 2 ou 3?<p> <p>Les sons ne peuvent être joués qu'une seule fois!<p>")
	        .center()
	        .css("background", "white")
	    ,
	    newButton("hc6_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc6", "Le PREMIER son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("incorrect2_hc6", "Le DEUXIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("correct_hc6", "Le TROISIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    getButton("hc6_play")
	        .wait()
	    ,
	    newAudio("hc6","antiphase_HC_OIS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc6")
	        .add(getText("incorrect1_hc6"), getText("incorrect2_hc6"), getText("correct_hc6"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc6")
	        .test.selected(getText("correct_hc6"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc2_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc2", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc2", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc2", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc2_play")
	        .wait()
	    ,
	    newAudio("hc2","antiphase_HC_IOS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc2")
	        .add(getText("incorrect1_hc2"), getText("incorrect2_hc2"), getText("correct_hc2"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc2")
	        .test.selected(getText("correct_hc2"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc1_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc1", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc1", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc1", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc1_play")
	        .wait()
	    ,
	    newAudio("hc1","antiphase_HC_ISO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc1")
	        .add(getText("incorrect1_hc1"), getText("correct_hc1"), getText("incorrect2_hc1"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc1")
	        .test.selected(getText("correct_hc1"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc4_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc4", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect1_hc4", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc4", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc4_play")
	        .wait()
	    ,
	    newAudio("hc4","antiphase_HC_SIO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc4")
	        .add(getText("correct_hc4"), getText("incorrect1_hc4"), getText("incorrect2_hc4"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc4")
	        .test.selected(getText("correct_hc4"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc3_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc3", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect1_hc3", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc3", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc3_play")
	        .wait()
	    ,
	    newAudio("hc3","antiphase_HC_SOI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc3")
	        .add(getText("correct_hc3"), getText("incorrect1_hc3"), getText("incorrect2_hc3"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc3")
	        .test.selected(getText("correct_hc3"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc5_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc5", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc5", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc5", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc5_play")
	        .wait()
	    ,
	    newAudio("hc5","antiphase_HC_OSI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc5")
	        .add(getText("incorrect1_hc5"), getText("correct_hc5"), getText("incorrect2_hc5"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc5")
	        .test.selected(getText("correct_hc5"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("send", "Envoyer")
	        .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait()
);

newTrial("hc_results",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .success(
            newText("<p>Très bien!</p><p>Appuyez sur le bouton ci-dessous pour continuer.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("Continuer")
                .center()
                .size(100, 30)
                .css("border", "solid 5px white")
                .print()
                .wait()
                
        )
        .failure(
            newText("<p>Veuillez mettre des écouteurs et réessayer l'expérience plus tard.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newTimer(2500)
                .start()
                .wait()
        )
);


//General Instructions

newTrial("general-instructions",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("<p> <strong>Bienvenue dans la troisième partie de l'étude « Apprentissage des mots » à l'Université de Potsdam ! </strong> </p> <p>Vous allez effectuer trois tâches durant cette session.  Avant chaque tâche, veuillez lire les instructions.<p> Assurez-vous que vous êtes dans une pièce calme et que le son de votre appareil est activé. <p> L'ensemble de l'expérience devrait prendre environ 30 minutes. Votre identité restera anonyme et vos données seront traitées et stockées conformément à la loi européene sur la protection des données (DSGVO). </strong> </p> Afin de participer à l'étude en cours, veuillez vous assurer que vous utilisez le navigateur Google Chrome ou Firefox. </p> <p> Si vous utilisez un autre navigateur, veuillez fermer la fenêtre de l'expérience et vous retirer de l'étude. <p></p> Assurez- vous également que vous porter des écouteurs et que le son est activé. ")
    ,
    newText("Veuillez saisir votre Prolific ID et cliquer sur le bouton ci-dessous pour continuer.")
    ,
    newTextInput("input_ID")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newButton("wait", "Continuer")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
        .wait(getTextInput("input_ID").testNot.text(""))
    ,
    newVar("ID")
        .global()
        .set(getTextInput("input_ID"))
        .log() 
);


//audio Check

    newTrial("audio_check",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultText
            .center()
            .print()
        ,
        newText("<p></strong>Veuillez participer à cette expérience uniquement si vous êtes dans une pièce calme.</strong></p><p>Assurez-vous que votre microphone fonctionne correctement et que votre voix est suffisamment forte.<p> <p>Vous pouvez le faire en effectuant les étapes suivantes (plusieurs fois si nécessaire) :<p><p>1. Cliquez sur le bouton Record et prononcez les mots : Test Test Test.<p><p>2. Cliquez sur le bouton Stop.<p><p>3. Cliquez sur le bouton Lecture pour vérifier si l'enregistrement est réussi et si le son est suffisamment fort.<p><p>Cliquez sur Continuer si l'enregistrement est réussi. Si la qualité audio de l'enregistrement est mauvaise, veuillez ne pas continuer à participer à l'expérience (avec votre ordinateur et votre microphone actuels).<p>")
	        .center()
	        .css("background", "white")
        ,
        newMediaRecorder("ac_recorder", "audio")
            .center()
            .print()
	        .css("border" , "solid 3px red" )
        ,
        newButton("ac_test_button", "Continuer")
            .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait(getMediaRecorder("ac_recorder").test.recorded())
    );


// Instructions for naming task
newTrial("instructions-naming-task",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText ("Tâche 1")
        .bold()
    ,
    newText("Dans la première tâche, vous verrez des images des mots que vous avez appris, apparaître une à une à l’écran.")
    ,
    newText("<b>Dites le nom de chaque image à voix haute aussi rapidement que possible et sans faire d’erreurs.</b> ")
    ,
    newText("Chaque image est présentée à l'écran pendant 5 secondes. ")
    ,
    newText("Vous commencerez par un essai.")
    ,
    newButton("wait", "Cliquez pour démarrer l’essai.")
        .center()
        .print()
        .wait()
);

// Trial run for naming task

Template("TrialTask.csv", row =>
    newTrial("trial-run-naming",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        defaultText
            .cssContainer({"margin-bottom":"1em"})
            .cssContainer("font-size", "20px")
            .center()
        ,
        defaultImage
            .cssContainer({"margin-bottom":"1em"})
            .size(400,400)
            .center()
        ,
        newText("imagine", "Imaginez que vous avez appris le mot <b>flid</b> et que cette image le représente.")
            .print()
        ,
        newImage("picture", row.image)
            .print()
        ,
        newButton("ok", "OK")
            .center()
            .print()
            .wait()
        ,
        getButton("ok")
            .remove()
        ,
        getText("imagine")
            .remove()
        ,
        getImage("picture")
            .remove()
        ,
        newText("inst", "Lorsque vous voyez à nouveau l'image, dites <b>flid</b> À HAUTE VOIX.")
            .print()
        ,
        newButton("ok2", "OK")
            .center()
            .print()
            .wait()
        ,
        getText("inst")
            .remove()
        ,
        getButton("ok2")
            .remove()
        ,
        newImage("fixation", "cross.jpg")
            .size(100,100)
        ,
        newCanvas("location")
            .add(650, 80, getImage("fixation"))
            .print()
            .log()
        ,
        newTimer("wait", 500)
            .start()
            .wait()
        ,
        getImage("fixation")
            .remove()
        ,
        newImage("pictureagain", "flidtrial.jpg")
            .print()
        ,
        newMediaRecorder(uniqueID+"_"+row.word, "audio")
            .hidden()
            .record()
        ,
        newTimer("timer",5000)
            .start()
            .wait()
        ,
        getMediaRecorder(uniqueID+"_"+row.word)
            .stop()
    )
    .log("uniqueID", uniqueID)
);

//ask if ready to start

newTrial("clear?",
    getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
    newText("L'essai est terminé!")
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour démarrer l'expérience")
        .center()
        .print()
        .wait()
);

// Naming task with AudioRecorder

Template("NamingTask.csv", row =>
    newTrial("naming-task",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newImage("fixation", "cross.jpg")
            .size(100,100)
        ,
        newCanvas("location")
            .add(650, 80, getImage("fixation"))
            .print()
            .log()
        ,
        newTimer("wait", 500)
            .start()
            .wait()
        ,
        getImage("fixation")
            .remove()
        ,
        newImage("picture", row.image)
            .cssContainer({"margin-bottom":"1em"})
            .size(400, 400)
            .center()
            .print()
            .log()
        ,
        newMediaRecorder(uniqueID+"_"+row.word, "audio")
            .hidden()
            .record()
            .log()
        ,
        newTimer("timer",5000)
            .start()
            .wait()
        ,
        getMediaRecorder(uniqueID+"_"+row.word)
            .stop()
            .log()
    )
    .log("item", row.word)
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
);

// READING TASK ButtonGroup = FJ (F - yes, J - no)

//Instructions for reading task

newTrial("instructions-reading-task-FJ",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText("Tâche 2")
        .bold()
    ,
    newText("Dans cette tâche, vous verrez des séquences de lettres apparaitre une à une à l’écran.")
    ,
    newText(" Certaines correspondent à des nouveaux mots que vous avez appris durant l’expérience, d’autres non.")
    ,
    newText("Appuyez sur <b>F</b> (oui) si vous avez <b>appris</b> le mot.")
    ,
    newText("Appuyez sur <b>J</b> (non) si vous <b>n'avez pas appris</b>")
    ,
    newText("Répondez le plus rapidement possible sans faire d’erreurs. ")
    ,
    newText("Vous commencerez par un essai.")
    ,
    newButton("wait", "Cliquez pour démarrer l’essai.")
        .center()
        .print()
        .wait()
);

//Trial run for reading task 

Template("TrialTask.csv", row =>
    newTrial("trial-run-reading-FJ",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        defaultText
            .cssContainer({"margin-bottom":"1em"})
            .css("font-size","20px")
            .center()
        ,
        newText("imagine","Appuyez sur <b>F</b> (oui) si vous avez <b>appris</b> le mot.")
            .print()
        ,
        newText("imagine2","Appuyez sur <b>J</b> (non) si vous <b>n'avez pas appris</b> le mot.")
            .print()
        ,
        newButton("ok","OK")
            .center()
            .print()
            .wait()
        ,
        getText("imagine")
            .remove()
        ,
        getText("imagine2")
            .remove()
        ,
        getButton("ok")
            .remove()
        ,
        newText("word", row.word)
            .css("font-size","80px")
            .center()
            .print()
            .cssContainer({"margin-bottom":"3em"})
        ,
        newText("F", "oui(F)")
            .css("font-size","20px")
        ,
        newText("J", "non(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log() 
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer", "FJ")
            .log("first")
            .wait()
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .stop()
    )
);


// ask if ready to start

newTrial("clear?2",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    newText("L'essai est terminé!")
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour démarrer l'expérience")
        .center()
        .print()
        .wait()
);

// Reading task: 4 lists for 4 participant groups

Template("ReadingTaskList1_FJ.csv", row =>
    newTrial("reading-task1-FJ",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "oui(F)")
            .css("font-size","20px")
        ,
        newText("J", "non(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup", row.ButtonGroup)
);

Template("ReadingTaskList2_FJ.csv", row =>
    newTrial("reading-task2-FJ",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "oui(F)")
            .css("font-size","20px")
        ,
        newText("J", "non(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup", row.ButtonGroup)
);

Template("ReadingTaskList3_FJ.csv", row =>
    newTrial("reading-task3-FJ",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "oui(F)")
            .css("font-size","20px")
        ,
        newText("J", "non(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);

Template("ReadingTaskList4_FJ.csv", row =>
    newTrial("reading-task4-FJ",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "oui(F)")
            .css("font-size","20px")
        ,
        newText("J", "non(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);


// READING TASK ButtonGroup = JF (J - yes, F - no)

//Instructions for reading task

newTrial("instructions-reading-task-JF",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText("Tâche 2")
        .bold()
    ,
    newText("Dans cette tâche, vous verrez des séquences de lettres apparaitre une à une à l’écran.")
    ,
    newText(" Certaines correspondent à des nouveaux mots que vous avez appris durant l’expérience, d’autres non.")
    ,
    newText("Appuyez sur <b>J</b> (oui) si vous avez <b>appris</b> le mot.")
    ,
    newText("Appuyez sur <b>F</b> (non) si vous <b>n'avez pas appris</b>")
    ,
    newText("Répondez le plus rapidement possible sans faire d’erreurs. ")
    ,
    newText("Vous commencerez par un essai.")
    ,
    newButton("wait", "Cliquez pour démarrer l’essai.")
        .center()
        .print()
        .wait()
);

//Trial run for reading task 

Template("TrialTask.csv", row =>
    newTrial("trial-run-reading-JF",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        defaultText
            .cssContainer({"margin-bottom":"1em"})
            .css("font-size","20px")
            .center()
        ,
        newText("imagine","Appuyez sur <b>J</b> (oui) si vous avez <b>appris</b> le mot.")
            .print()
        ,
        newText("imagine2","Appuyez sur <b>F</b> (non) si vous <b>n'avez pas appris</b> le mot.")
            .print()
        ,
        newButton("ok","OK")
            .center()
            .print()
            .wait()
        ,
        getText("imagine")
            .remove()
        ,
        getText("imagine2")
            .remove()
        ,
        getButton("ok")
            .remove()
        ,
        newText("word", row.word)
            .css("font-size","80px")
            .center()
            .print()
            .cssContainer({"margin-bottom":"1em"})
        ,
        newText("F", "non(F)")                                   
            .css("font-size","20px")
        ,
        newText("J", "oui(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",10000)
            .start()
        ,
        newKey("answer", "FJ")
            .log("first")
            .wait()
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .stop()
    )
);


// ask if ready to start

newTrial("clear?2",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    newText("L'essai est terminé!")
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour démarrer l'expérience")
        .center()
        .print()
        .wait()
);

// Reading task: 4 lists for 4 participant groups

Template("ReadingTaskList1_JF.csv", row =>
    newTrial("reading-task1-JF",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "non(F)")                                   
            .css("font-size","20px")
        ,
        newText("J", "oui(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);

Template("ReadingTaskList2_JF.csv", row =>
    newTrial("reading-task2-JF",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "non(F)")                                   
            .css("font-size","20px")
        ,
        newText("J", "oui(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);

Template("ReadingTaskList3_JF.csv", row =>
    newTrial("reading-task3-JF",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .cssContainer({"margin-bottom":"3em"})
            .css("font-size","80px")
            .center()
            .print()
            .log()
        ,
        newText("F", "non(F)")                                   
            .css("font-size","20px")
        ,
        newText("J", "oui(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);

Template("ReadingTaskList4_JF.csv", row =>
    newTrial("reading-task4-JF",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .css("font-size","80px")
            .center()
            .print()
            .log()
            .cssContainer({"margin-bottom":"3em"})
        ,
        newText("F", "non(F)")                                   
            .css("font-size","20px")
        ,
        newText("J", "oui(J)")
            .css("font-size","20px")
        ,
        newCanvas("side-by-side", 450,200)
            .add(50, 0, getText("F"))
            .add(300, 0, getText("J"))
            .center()
            .print()
            .log()
        ,
        newTimer("timeout",5000)
            .start()
        ,
        newKey("answer","FJ")
            .log("first")
            .callback(getTimer("timeout").stop())
        ,
        getTimer("timeout")
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("condition", row.condition)
    .log("ButtonGroup",row.ButtonGroup)
);


//Instructions for dictation task

newTrial("instructions-dictation-task",
    getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText("Tâche 3")
        .bold()
    ,
    newText("Il s’agit d’une dictée. Dans cette tâche, les nouveaux mots que vous avez appris seront présentés un par un à l’oral.")
    ,
    newText("Pour chacun d’eux, et dès que vous l’entendez, écrivez le à l’aide du clavier.")
    ,
    newText("Cliquez sur ENVOYER pour passer au mot suivant.")
    ,
    newText("Vous commencerez par un essai.")
    ,
    newButton("wait", "Cliquez pour démarrer l’essai")
        .center()
        .print()
        .wait()
);

// Trial run for dictation task 

Template("TrialTask.csv", row =>
    newTrial("trial-run-dictation",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newText("instruction", "Listen!")
            .css("font-size", "30px")
            .center()
            .print()
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newAudio("audio", row.audio )
            .play()
            .wait()
        ,
        getText("instruction")
            .remove()
        ,
        newTimer("break2",600)
            .start()
            .wait()
        ,
        newTextInput("answer","")
            .center()
            .before(newText("Veuillez saisir le mot   ").css("font-size","20px").center())
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        newButton("send", "ENVOYER")
            .center()
            .print()
            .wait( getTextInput("answer").testNot.text("") )
        ,
        newVar("spelling")
            .global()
            .set(getTextInput("answer"))
    )
);

//ask if ready to start

newTrial("clear?3",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    newText("L'essai est terminé!")
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour démarrer l'expérience")
        .center()
        .print()
        .wait()
);

//Dictation task

Template("DictationTask.csv", row =>
    newTrial("dictation-task",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newText("instruction", "Écoute !")
            .css("font-size", "30px")
            .center()
            .print()
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        
        newAudio("audio", row.audio)
            .play()
            .wait()
        ,
        getText("instruction")
            .remove()
        ,
        newTimer("break2",600)
            .start()
            .wait()
        ,
        newTextInput("answer","")
            .center()
            .before(newText("Veuillez saisir le mot   ").css("font-size","20px").center())
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        newButton("send", "ENVOYER")
            .center()
            .print()
            .wait( getTextInput("answer").testNot.text("") )
        ,
        newVar("spelling")
            .global()
            .set(getTextInput("answer"))
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("spelling", getVar("spelling"))
    .log("item", row.item)
);

//Instructions for reading french words

//Instructions for dictation task

newTrial("instructions-french-words",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText("Tâche 4")
        .bold()
    ,
    newText("Les mots français apparaîtront un par un. S'il vous plait, lisez-les à haute voix. Vous serez enregistré.")
    ,
    newText("Dès qu'un mot est affiché à l'écran, l'enregistrement démarre. Chaque mot restera à l'écran pendant 5 secondes.")
    ,
    newText("Ne vous précipitez pas, mais commencez à lire le mot à haute voix dès qu'il est affiché. ")
    ,
    newText("Il n'y a pas d'essai.")
    ,
    newButton("wait", "Cliquez pour démarrer la tâche")
        .center()
        .print()
        .wait()
);

//French words recording

Template("French_words.csv", row =>
    newTrial("french_words",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newTimer("break", 1000)
            .start()
            .wait()
        ,
        newText("word", row.word)
            .css("font-size","80px")
            .center()
            .print()
            .log()
            .cssContainer({"margin-bottom":"3em"})
        ,
        newMediaRecorder(uniqueID+"_"+row.word, "audio")
            .hidden()
            .record()
            .log()
        ,
        newTimer("timer",5000)
            .start()
            .wait()
        ,
        getMediaRecorder(uniqueID+"_"+row.word)
            .stop()
            .log()
    )
    .log("ID", getVar("ID"))
    .log("uniqueID", uniqueID)
    .log("item", row.word)
    .log("vowel", row.vowel)
);


// Completion screen

newTrial("completion-screen",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer({"margin-bottom":"1em"})
        .cssContainer("font-size", "20px")
        .center()
        .print()
    ,
    newText("thanks", "Merci d'avoir participé ! Un questionnaire vous sera envoyé via des messages sur Prolific. Veuillez le compléter en utilisant votre identifiant Prolific.")
    ,
    newText("exit", "Cliquez sur le lien pour terminer la session: https://app.prolific.co/submissions/complete?cc=C1OSK1UH ")
    ,
    newButton("wait", "")
        .wait()
        .log()
);

Template(GetTable("final_message_3.csv"),
    fin =>
        newTrial("completion-screen",
            getVar("counter_hc")
                .test.is(v => v > 4)
                .failure(end())
            ,
            exitFullscreen()
            ,
            defaultText
                .cssContainer({"margin-bottom":"1em"})
                .cssContainer("font-size", "20px")
                .center()
                .print()
            ,
            newText("thanks", "Merci d'avoir participé ! Un questionnaire vous sera envoyé via des messages sur Prolific. Veuillez le compléter en utilisant votre identifiant Prolific.")
            ,
            newText(fin.line1)
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("void")
                .wait()
        ));


