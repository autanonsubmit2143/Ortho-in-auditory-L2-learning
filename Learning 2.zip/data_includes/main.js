PennController.ResetPrefix();

DebugOff()

Sequence(
"hc_calib",
"screening_test", 
"hc_results", 
"general-instructions", 
"general-instructions2",
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
randomize("TokenOne"),randomize("TokenTwo"),randomize("TokenThree"),randomize("TokenFour"),
"instructions-matching-task", 
randomize("matching1"),
randomize("matching2"),
randomize("matching3"),
randomize("matching4"), 
"send", 
"final_message");

//headphone Check

newTrial("hc_calib",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .center()
            .print()
        ,
        newText("Test de perception")
            .bold()
        ,
        newText("<p></strong>Vous devez porter des écouteurs pour continuer</strong></p><p>Tout d'abord, réglez le volume de votre ordinateur à environ 25% <p> <p>Appuyez sur le bouton ci-dessous, puis augmentez le volume de votre ordinateur jusqu'à ce que le son soit suffisamment fort tout en étant confortable.<p><p>Vous pouvez écouter le sonet modifier votre volume autant de fois que vous le souhaitez.<p><p>Appuyez sur Continuer lorsque vous avez terminé<p>")
	        .center()
	        .css("background", "white")
        ,
        newAudio("noise_calib","noise_calib_stim.wav")
            .cssContainer({"margin-bottom":"1em"})
	        .css( "border" , "solid 3px red" )
	        .center()
            .print()
            .play()
        ,
        newButton("ac_test_button", "Continuer")
            .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait(getAudio("noise_calib").test.hasPlayed())
);


newTrial("screening_test",
        defaultText
            .cssContainer("font-size", "20px")
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        newVar("counter_hc",0)
            .global()
            .log("final")
        ,
        newText("Test de perception")
            .bold()
            .center()
        ,
        newText("<p></strong>Lorsque vous appuierez sur le bouton  <b>Lecture ci-dessous</b>, vous entendrez trois sons séparés par des silences.</strong></p><p>Vous devez décider LEQUEL DE CES TROIS SONS A LA PLUS FAIBLE INTENSITE (est le moins fort) - 1, 2 ou 3?<p> <p>Les sons ne peuvent être joués qu'une seule fois!<p>")
	        .center()
	        .css("background", "white")
	    ,
	    newButton("hc3_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc3", "Le PREMIER son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("incorrect1_hc3", "Le DEUXIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    newText("incorrect2_hc3", "Le TROISIÈME son était le PLUS FAIBLE")
	        .print()
	    ,
	    getButton("hc3_play")
	        .wait()
	    ,
	    newAudio("hc3","antiphase_HC_SOI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc3")
	        .add(getText("correct_hc3"), getText("incorrect1_hc3"), getText("incorrect2_hc3"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc3")
	        .test.selected(getText("correct_hc3"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc1_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc1", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc1", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc1", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc1_play")
	        .wait()
	    ,
	    newAudio("hc1","antiphase_HC_ISO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc1")
	        .add(getText("incorrect1_hc1"), getText("correct_hc1"), getText("incorrect2_hc1"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc1")
	        .test.selected(getText("correct_hc1"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	   ,
	   newButton("hc2_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc2", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc2", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc2", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc2_play")
	        .wait()
	    ,
	    newAudio("hc2","antiphase_HC_IOS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc2")
	        .add(getText("incorrect1_hc2"), getText("incorrect2_hc2"), getText("correct_hc2"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc2")
	        .test.selected(getText("correct_hc2"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc5_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc5", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc5", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc5", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc5_play")
	        .wait()
	    ,
	    newAudio("hc5","antiphase_HC_OSI.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc5")
	        .add(getText("incorrect1_hc5"), getText("correct_hc5"), getText("incorrect2_hc5"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc5")
	        .test.selected(getText("correct_hc5"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("hc4_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("correct_hc4", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect1_hc4", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc4", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc4_play")
	        .wait()
	    ,
	    newAudio("hc4","antiphase_HC_SIO.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc4")
	        .add(getText("correct_hc4"), getText("incorrect1_hc4"), getText("incorrect2_hc4"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc4")
	        .test.selected(getText("correct_hc4"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    
	    newButton("hc6_play", "Lecture")
	        .size(100, 30)
	        .css("border", "solid 5px white")
	        .once()
	        .print()
	    ,
	    newText("incorrect1_hc6", "Le PREMIER son était le PLUS DOUX")
	        .print()
	    ,
	    newText("incorrect2_hc6", "Le DEUXIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    newText("correct_hc6", "Le TROISIÈME son était le PLUS DOUX")
	        .print()
	    ,
	    getButton("hc6_play")
	        .wait()
	    ,
	    newAudio("hc6","antiphase_HC_OIS.wav")
	        .once()
	        .play()
	        .wait()
	    ,
	    newSelector("choice_hc6")
	        .add(getText("incorrect1_hc6"), getText("incorrect2_hc6"), getText("correct_hc6"))
	        .frame("dashed 3px violet")
	        .wait()
	    ,
	    getSelector("choice_hc6")
	        .test.selected(getText("correct_hc6"))
	        .success(
	            getVar("counter_hc")
	                .set(v => v+1))
	    ,
	    newButton("send", "Envoyer")
	        .center()
            .size(100, 30)
            .css("border", "solid 5px white")
            .print()
            .wait()
);

newTrial("hc_results",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .success(
            newText("<p>Très bien!</p><p>Appuyez sur le bouton ci-dessous pour continuer.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("Continuer")
                .center()
                .size(100, 30)
                .css("border", "solid 5px white")
                .print()
                .wait()
                
        )
        .failure(
            newText("<p>Veuillez mettre des écouteurs et réessayer l'expérience plus tard.</p>")
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newTimer(2500)
                .start()
                .wait()
        )
);

//Instructions

newTrial("general-instructions",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("<p> <strong> Phase d’apprentissage - 2 </strong> </p>")
    ,
    newText("Temps de complétion estimé à 25 minutes.")
    ,
    newText("Veuillez saisir votre Prolific ID et cliquer sur le bouton ci-dessous pour continuer.")
    ,
    newTextInput("input_ID")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newButton("wait", "Cliquez pour continuer")
        .center()
        .print()
        .wait()
    ,
    newVar("ID")
        .global()
        .set(getTextInput("input_ID"))
        .log()
);

newTrial("general-instructions2",
    getVar("counter_hc")
        .test.is(v => v > 4)
        .failure(end())
    ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("Phase d’apprentissage - 2")
        .bold()
    ,
    newText("<p>Durant cette session, vous allez être familiarisés avec 20 nouveaux mots anglais, votre tâche consiste à les mémoriser et à vous rappeler l’image à laquelle ils correspondent. <p>Vous verrez apparaître à l’écran des images de plantes, d’animaux et d’objets. Les images apparaitront l’une après l’autre, accompagnées du mot qu’elles représentent. Votre tâche est d’apprendre le plus de mots possibles.")
    ,
    newText("Vous n'êtes PAS AUTORISÉ à prendre des notes.")
    ,
    newText("Assurez-vous que le son de votre appareil est activé.")
        .bold()
    ,
    newButton("wait", "Cliquez pour commencer")
        .center()
        .print()
        .wait()
);

//Learning 

Template("LearningSession_TokenOne.csv", row =>
    newTrial("TokenOne",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
);

Template("LearningSession_TokenTwo.csv", row =>
    newTrial("TokenTwo",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
);

Template("LearningSession_TokenThree.csv", row =>
    newTrial("TokenThree",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
            newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
);

Template("LearningSession_TokenFour.csv", row =>
    newTrial("TokenFour",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        defaultImage.size(400,400)
        ,
        newImage("picture", row.image)
            .center()
            .print()
        ,
                newTimer("timer", 1000)
            .start()
            .wait()
        ,
        newAudio("audio",row.audio)
            .play()
        ,
        newTimer("timer", 3000)
            .start()
            .wait()
        )
        .log("ID", getVar("ID"))
);

//Instructions for matching task

newTrial("instructions-matching-task",
    getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
    defaultText
        .cssContainer("font-size", "20px")
        .cssContainer({"margin-bottom":"1em"})
        .center()
        .print()
    ,
    newText("Appariement d’image")
        .bold()
    ,
    newText("Dans cette tâche, vous entendrez les mots un par un.")
    ,
    newText("Pour chaque mot, deux images seront présentées à l'écran.")
    ,
    newText("Veuillez indiquer quelle image correspond au mot que vous avez entendu. ")
    ,
    newText ("Utilisez <b>F</b> pour choisir l'image <b>gauche</b> ou utilisez <b>J</b> pour choisir l'image <b>droite</b>.")
    ,
    newButton("wait", "Cliquez pour démarrer la tâche")
        .center()
        .print()
        .wait()
);


//picture matching tasks 


//1


Template("Matching.csv", row =>
    newTrial("matching1",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newVar("counter1",0)
            .log("final")
        ,
        defaultText
            .center()
            .bold()
        ,
        defaultImage
            .size(200,200)
        ,
        newCanvas("side-by-side",450,200)
            .add(0,0,newImage("right_picture", row.right_image))
            .add(250,0,newImage("wrong_picture", row.wrong_image))
            .center()
            .print()
        ,
        newAudio("audio", row.audio)
            .play()
            .log("play")
        ,
        newSelector("choice")
            .disableClicks()
            .add(getImage("right_picture"), getImage("wrong_picture"))
            .shuffle()
            .keys("F","J")
            .once()
            .log("all")
            .wait()
        ,
        getSelector("choice")
            .test.selected(getImage("right_picture"))
            .success(
                getVar("counter1")
                    .set(v => v+1)
                ,
                newText("positive feedback", "<p>  <p> Correct!")
                    .cssContainer({"font-size": "130%", "color": "green"})
                    .print()
                )
            .failure(
                newText("negative feedback", "<p>  <p> Incorrect!")
                    .cssContainer({"font-size": "130%", "color": "red"})
                    .print()
                )
            
        ,
        newTimer(500)
            .start()
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("item", row.item)
);

// 2

Template("Matching2.csv", row =>
    newTrial("matching2",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newVar("counter2",0)
            .log("final")
        ,
        defaultText
            .center()
            .bold()
        ,
        defaultImage.size(200,200)
        ,
        newCanvas("side-by-side",450,200)
            .add(0,0,newImage("right_picture", row.right_image))
            .add(250,0,newImage("wrong_picture", row.wrong_image))
            .center()
            .print()
        ,
        newAudio("audio", row.audio)
            .play()
            .log("play")
        ,
        newSelector("choice")
            .disableClicks()
            .add(getImage("right_picture"), getImage("wrong_picture"))
            .shuffle()
            .keys("F","J")
            .once()
            .log("all")
            .wait()
        ,
        getSelector("choice")
            .test.selected(getImage("right_picture"))
            .success(
                getVar("counter2")
                    .set(v => v+1)
                ,
                newText("positive feedback", "<p>  <p> Correct!")
                    .cssContainer({"font-size": "130%", "color": "green"})
                    .bold()
                    .print()
                )
            .failure(
                newText("negative feedback", "<p>  <p> Incorrect!")
                    .cssContainer({"font-size": "130%", "color": "red"})
                    .bold()
                    .print()
                )
            
        ,
        newTimer(500)
            .start()
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("item", row.item)
);

// 3

Template("Matching3.csv", row =>
    newTrial("matching3",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newVar("counter3",0)
            .log("final")
        ,
        defaultText
            .center()
            .bold()
        ,
        defaultImage.size(200,200)
        ,
        newCanvas("side-by-side",450,200)
            .add(0,0,newImage("right_picture", row.right_image))
            .add(250,0,newImage("wrong_picture", row.wrong_image))
            .center()
            .print()
        ,
        newAudio("audio", row.audio)
            .play()
            .log("play")
        ,
        newSelector("choice")
            .disableClicks()
            .add(getImage("right_picture"), getImage("wrong_picture"))
            .shuffle()
            .keys("F","J")
            .once()
            .log("all")
            .wait()
        ,
        getSelector("choice")
            .test.selected(getImage("right_picture"))
            .success(
                getVar("counter2")
                    .set(v => v+1)
                ,
                newText("positive feedback", "<p>  <p> Correct!")
                    .cssContainer({"font-size": "130%", "color": "green"})
                    .bold()
                    .print()
                )
            .failure(
                newText("negative feedback", "<p>  <p> Incorrect!")
                    .cssContainer({"font-size": "130%", "color": "red"})
                    .bold()
                    .print()
                )
            
        ,
        newTimer(500)
            .start()
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("item", row.item)
);

// 4

Template("Matching4.csv", row =>
    newTrial("matching4",
        getVar("counter_hc")
            .test.is(v => v > 4)
            .failure(end())
        ,
        newVar("counter4",0)
            .log("final")
        ,
        defaultText
            .center()
            .bold()
        ,
        defaultImage.size(200,200)
        ,
        newCanvas("side-by-side",450,200)
            .add(0,0,newImage("right_picture", row.right_image))
            .add(250,0,newImage("wrong_picture", row.wrong_image))
            .center()
            .print()
        ,
        newAudio("audio", row.audio)
            .play()
            .log("play")
        ,
        newSelector("choice")
            .disableClicks()
            .add(getImage("right_picture"), getImage("wrong_picture"))
            .shuffle()
            .keys("F","J")
            .once()
            .log("all")
            .wait()
        ,
        getSelector("choice")
            .test.selected(getImage("right_picture"))
            .success(
                getVar("counter4")
                    .set(v => v+1)
                ,
                newText("positive feedback", "<p>  <p> Correct!")
                    .cssContainer({"font-size": "130%", "color": "green"})
                    .bold()
                    .print()
                )
            .failure(
                newText("negative feedback", "<p>  <p> Incorrect!")
                    .cssContainer({"font-size": "130%", "color": "red"})
                    .bold()
                    .print()
                )
            
        ,
        newTimer(500)
            .start()
            .wait()
    )
    .log("ID", getVar("ID"))
    .log("item", row.item)
);

SendResults("send");

// Completion screen

Template(GetTable("final_message_2.csv"),
    fin =>
        newTrial("final_message",
            getVar("counter_hc")
                .test.is(v => v > 4)
                .failure(end())
            ,
            exitFullscreen()
            ,
            newText(fin.line1)
                .cssContainer("font-size", "20px")
                .cssContainer({"margin-bottom":"1em"})
                .center()
                .print()
            ,
            newButton("void")
                .wait()
        ));
